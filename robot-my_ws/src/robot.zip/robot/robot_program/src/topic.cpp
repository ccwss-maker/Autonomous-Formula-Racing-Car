#include "string.h"  
#include "stdio.h"
#include "sstream"
#include "termio.h"
#include <iostream>
#include <vector>
#include "ros/ros.h"  
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "sensor_msgs/JointState.h"
#include "sensor_msgs/Image.h"
#include "geometry_msgs/Twist.h"
#include "darknet_ros_msgs/BoundingBoxes.h"
#include "boost/thread.hpp"
#include "cv_bridge/cv_bridge.h"
#include  "opencv2/opencv.hpp"
#include  "opencv2/highgui.hpp"
#include  "opencv2/imgproc/imgproc_c.h""

using namespace ros;
using namespace std;
using namespace std_msgs;
using namespace geometry_msgs;
using namespace darknet_ros_msgs;
using namespace sensor_msgs;
using namespace cv;
using namespace  cv_bridge;
#define PI 3.1415926
#define joint_NUM 6

typedef struct
{
    char name;
    Point point;
}color_;

typedef struct
{
    int sum;
    int red;
    int blue;
    int yellow;
}count_;

typedef struct
{
    count_ count;
    int sign;//1 : r > b;       0 : r < b;
    color_ red[30];
    color_ blue[30];
    color_ yellow[30];
}darknet_;

typedef struct
{
    char name[joint_NUM][36];      
    double  position[joint_NUM];
    double  velocity[joint_NUM];
    double  effort[joint_NUM];
}joint_states_;

darknet_ darknet;
joint_states_ joint_states;

int scanKeyboard();
Mat polyfit(vector<Point>& in_point, int n , char x);

class SubscribeAndPublish  
{  
    public:  
    SubscribeAndPublish()  
    {  
        //publish  
        cmd_vel_pub=n_.advertise<Twist>("/cmd_vel",1);
        left_string_pub= n_.advertise<Float64>("/car/left_string_position_controller/command", 1);  
        right_string_pub= n_.advertise<Float64>("/car/right_string_position_controller/command", 1);  
        //subscribe  
        joint_states_sub = n_.subscribe("/car/joint_states", 1, &SubscribeAndPublish::joint_states_callback, this); 
        darknet_msg_sub = n_.subscribe("/darknet_ros/bounding_boxes", 1, &SubscribeAndPublish::darknet_msg_callback, this); 
        image_sub = n_.subscribe("/car/camera/image", 1, &SubscribeAndPublish::image_callback, this); 

    }  
    void image_callback(const ImageConstPtr & msg);
    void joint_states_callback(const JointStateConstPtr & msg);  
    void darknet_msg_callback(const BoundingBoxesConstPtr & msg);
    void input();
    private:  
    NodeHandle n_;   
    Publisher cmd_vel_pub;  
    Publisher left_string_pub;  
    Publisher right_string_pub; 
    Subscriber joint_states_sub;
    Subscriber darknet_msg_sub;
    Subscriber image_sub;
    Twist pub_cmd_vel;
    Float64 pub_left_string;
    Float64 pub_right_string;
};   

void SubscribeAndPublish::joint_states_callback(const JointStateConstPtr & msg)  
{     
    int i,j;
    static int sign=0,order[joint_NUM];
    if(sign==0)
    {
        char name[joint_NUM][36];
        for(i=0;i<joint_NUM;i++)
        {
            for(j=0;msg->name[i][j]!=0;j++)
            {
                name[i][j]=msg->name[i][j];
            }
            name[i][j]='\0';
        }

        for(j=0;j<joint_NUM;j++)
        {
            i=0;
            while (strcmp(name[i],joint_states.name[j]))
            {
                i++;
            }
            order[j]=i;
        }
        sign=1;
    }

    for(i=0;i<joint_NUM;i++)
    {
        joint_states.position[i]=msg->position[order[i]];
        joint_states.velocity[i]=msg->velocity[order[i]];
        joint_states.effort[i]=msg->effort[order[i]];
    }
    
    input();
    // for(i=0;i<joint_NUM;i++)
    // {
    //     std::cout<<joint_states_p->name[i]<<std::endl;
    //     std::cout<<joint_states_p->position[i]<<std::endl;
    //     std::cout<<joint_states_p->velocity[i]<<std::endl;
    //     std::cout<<joint_states_p->effort[i]<<std::endl<<std::endl;
    // }
    cmd_vel_pub.publish(pub_cmd_vel);
    left_string_pub.publish(pub_left_string);
    right_string_pub.publish(pub_right_string);
}
void SubscribeAndPublish::darknet_msg_callback(const BoundingBoxesConstPtr & msg)
{
    int i,count_y=0,count_r=0,count_b=0;
    int rx_sum=0,bx_sum=0;
    darknet.count.sum=msg->count;
    for(i=0;i<darknet.count.sum;i++)
    {
        if(msg->bounding_boxes[i].Class[0]=='r')
        {
            darknet.red[count_r].name='r';
            darknet.red[count_r].point.x=(msg->bounding_boxes[i].xmax+msg->bounding_boxes[i].xmin)/2;
            darknet.red[count_r].point.y=(msg->bounding_boxes[i].ymax+msg->bounding_boxes[i].ymin)/2;
            rx_sum+=darknet.red[count_r].point.x;
            count_r++;
        }
        else if(msg->bounding_boxes[i].Class[0]=='b')
        {
            darknet.blue[count_b].name='b';
            darknet.blue[count_b].point.x=(msg->bounding_boxes[i].xmax+msg->bounding_boxes[i].xmin)/2;
            darknet.blue[count_b].point.y=(msg->bounding_boxes[i].ymax+msg->bounding_boxes[i].ymin)/2;
            bx_sum+= darknet.blue[count_b].point.x;
            count_b++;
        }
        else if(msg->bounding_boxes[i].Class[0]=='y')
        {
            darknet.yellow[count_y].name='y';
            darknet.yellow[count_y].point.x=(msg->bounding_boxes[i].xmax+msg->bounding_boxes[i].xmin)/2;
            darknet.yellow[count_y++].point.y=(msg->bounding_boxes[i].ymax+msg->bounding_boxes[i].ymin)/2;
        }
    }
    darknet.count.blue=count_b;
    darknet.count.red=count_r;
    darknet.count.yellow=count_y;

    if(rx_sum/count_r>bx_sum/count_b)
        darknet.sign=1;
    else
        darknet.sign=0;
    
}

// mono8: CV_8UC1, grayscale image
// mono16: CV_16UC1, 16-bit grayscale image
// bgr8: CV_8UC3, color image with blue-green-red color order
// rgb8: CV_8UC3, color image with red-green-blue color order
// bgra8: CV_8UC4, BGR color image with an alpha channel
// rgba8: CV_8UC4, RGB color image with an alpha channel
void SubscribeAndPublish::image_callback(const ImageConstPtr & msg)
{
    static int a=0;
    static CvImagePtr cv_ptr; 
    static Mat src(msg->width,msg->height,CV_8UC3);
    vector<Point> blue_point;
    vector<Point> red_point;
    if(a==0)
    {
        namedWindow("img",WINDOW_FREERATIO);
        a=1;
    }
    cv_ptr = toCvCopy(msg, "bgr8");
    src=cv_ptr->image;

    if(darknet.sign==1)
    {
        darknet.red[darknet.count.red].point=Point(msg->width,msg->height);
        darknet.blue[darknet.count.blue].point=Point(0,msg->height);
    }
    else
    {
        darknet.red[darknet.count.red].point=Point(0,msg->height);
        darknet.blue[darknet.count.blue].point=Point(msg->width,msg->height);
    }
    int i;
    for(i=0;i<darknet.count.red+1;i++)
    {
        circle(src,darknet.red[i].point,10,Scalar(255,0,0),CV_FILLED,CV_AA);
        // if(darknet.red[i].point.x>msg->width/4&&darknet.red[i].point.x<msg->width*3/4)
            red_point.push_back(darknet.red[i].point);
    }
    for(i=0;i<darknet.count.blue+1;i++)
    {
        circle(src,darknet.blue[i].point,10,Scalar(0,0,255),CV_FILLED,CV_AA);
        // if(darknet.blue[i].point.x>msg->width/4&&darknet.blue[i].point.x<msg->width*3/4)
            blue_point.push_back(darknet.blue[i].point);
    }
    int n=3;
    Mat mat_r = polyfit(red_point, n ,'y');
    Mat mat_b = polyfit(blue_point, n, 'y');
    for (int i =msg->height/3; i <msg->height; i++)
	{
		Point ipt;
		ipt.x = i;
		ipt.y = 0;
		for (int j = 0; j < n + 1; ++j)
		{
			ipt.y += mat_r.at<double>(j, 0)*pow(i,j);
		}
		circle(src, Point(ipt.y,ipt.x), 10, Scalar(0, 0, 255), CV_FILLED, CV_AA);
	}

    for (int i =msg->height/3; i <msg->height; i++)
	{
		Point ipt;
		ipt.x = i;
		ipt.y = 0;
		for (int j = 0; j < n + 1; ++j)
		{
			ipt.y += mat_b.at<double>(j, 0)*pow(i,j);
		}
		circle(src, Point(ipt.y,ipt.x), 10, Scalar(255, 0, 0), CV_FILLED, CV_AA);
	}

    imshow("img",src);
    waitKey(1);
}

int main(int argc, char **argv)  
{
  //Initiate ROS  
  init(argc, argv, "subscribe_and_publish");  

  //Create an object of class SubscribeAndPublish that will take care of everything  
  SubscribeAndPublish test;  
  //spin();
  MultiThreadedSpinner s(3);  //多线程
  spin(s); 

  return 0;  
} 

int scanKeyboard()
{
    int in;
    struct termios new_settings;
    struct termios stored_settings;
    tcgetattr(0,&stored_settings);
    new_settings = stored_settings;
    new_settings.c_lflag &= (~ICANON);
    new_settings.c_cc[VTIME] = 0;
    tcgetattr(0,&stored_settings);
    new_settings.c_cc[VMIN] = 1;
    tcsetattr(0,TCSANOW,&new_settings);
    
    in = getchar();
    
    tcsetattr(0,TCSANOW,&stored_settings);
    return in;
}

void SubscribeAndPublish::input()
{
    int a;
    a=scanKeyboard();
    if(a=='w')
    {
        pub_cmd_vel.linear.x=20;
        pub_cmd_vel.linear.x=20;
    }
    else if(a=='s')
    {
        pub_cmd_vel.linear.x=-20;
        pub_cmd_vel.linear.x=-20;
    }
    else
    {
        pub_cmd_vel.linear.x=0;
        pub_cmd_vel.linear.x=0;
    }

    a=scanKeyboard();
    if(a=='a')
    {
        pub_left_string.data=10.0/180*PI;
        pub_right_string.data=10.0/180*PI;
    }
    else if(a=='d')
    {
        pub_left_string.data=-10.0/180*PI;
        pub_right_string.data=-10.0/180*PI;
    }
    else
    {
        pub_left_string.data=0;
        pub_right_string.data=0;
    }
}

Mat polyfit(vector<Point>& in_point, int n , char x)
{
	int size = in_point.size();
	//所求未知数个数
	int x_num = n + 1;
	//构造矩阵U和Y
	Mat mat_u(size, x_num, CV_64F);
	Mat mat_y(size, 1, CV_64F);
 
	for (int i = 0; i < mat_u.rows; ++i)
		for (int j = 0; j < mat_u.cols; ++j)
		{
            if(x=='x')
			    mat_u.at<double>(i, j) = pow(in_point[i].x, j);
            else if(x=='y')
                mat_u.at<double>(i, j) = pow(in_point[i].y, j);
		}
 
	for (int i = 0; i < mat_y.rows; ++i)
	{
        if(x=='x')
		    mat_y.at<double>(i, 0) = in_point[i].y;
        else if(x=='y')
            mat_y.at<double>(i, 0) = in_point[i].x;
	}
 
	//矩阵运算，获得系数矩阵K
	Mat mat_k(x_num, 1, CV_64F);
	mat_k = (mat_u.t()*mat_u).inv()*mat_u.t()*mat_y;
	// cout << mat_k << endl;
	return mat_k;
}




