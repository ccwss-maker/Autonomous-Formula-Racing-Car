#include "string.h"  
#include "stdio.h"
#include "sstream"
#include "termio.h"
#include <iostream>
#include <vector>
#include "ros/ros.h"  
#include "sensor_msgs/Image.h"
#include "boost/thread.hpp"
#include "cv_bridge/cv_bridge.h"
#include  "opencv2/opencv.hpp"
#include  "opencv2/highgui.hpp"

using namespace ros;
using namespace std;
using namespace sensor_msgs;
using namespace cv;
using namespace  cv_bridge;
#define PI 3.1415926

typedef struct
{
    char name;
    Point point;
}color_;

typedef struct
{
    int sum;
    int red;
    int blue;
    int yellow;
}count_;

typedef struct
{
    count_ count;
    int sign;//1 : r > b;       0 : r < b;
    color_ red[30];
    color_ blue[30];
    color_ yellow[30];
}roadblock_;

roadblock_ roadblock;

Mat roadline(const ImageConstPtr & msg,Mat src);
Mat polyfit(vector<Point>& in_point, int n , char x);

class SubscribeAndPublish  
{  
    public:  
    SubscribeAndPublish()  
    {  
        //publish  

        //subscribe  
        image_sub = n_.subscribe("/car/camera/image", 1, &SubscribeAndPublish::image_callback, this); 

    }  
    void image_callback(const ImageConstPtr & msg);
    private:  
    NodeHandle n_;   
    Subscriber image_sub;
};   

// mono8: CV_8UC1, grayscale image
// mono16: CV_16UC1, 16-bit grayscale image
// bgr8: CV_8UC3, color image with blue-green-red color order
// rgb8: CV_8UC3, color image with red-green-blue color order
// bgra8: CV_8UC4, BGR color image with an alpha channel
// rgba8: CV_8UC4, RGB color image with an alpha channel
void SubscribeAndPublish::image_callback(const ImageConstPtr & msg)
{
    static int a=0;
    static CvImagePtr cv_ptr; 
    static Mat src(msg->width,msg->height,CV_8UC3);
    
    cv_ptr = toCvCopy(msg, "bgr8");
    src=cv_ptr->image;

    Mat polydp=Mat(src.size(),src.type()),laplacian_,sharp,dst;
    polydp=Scalar(0,0,0);
	
    Mat gauss;
    GaussianBlur(src,gauss,Size(11,11),0,0);
    cvtColor(gauss,gauss,COLOR_RGB2GRAY);
	
    Mat binary;
    Mat kernel=getStructuringElement(MORPH_ELLIPSE,Size(3,3));
    threshold(gauss,binary,150,255,THRESH_BINARY_INV);
    //adaptiveThreshold(gauss,binary,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,11,0);
    morphologyEx(binary,binary,MORPH_CLOSE,kernel,Point(-1,-1),1);

    Mat canny;
    Canny(binary,canny,150/3,150,3);

    Mat contours_=Mat::zeros(src.size(),src.type());
    vector<vector<Point>> contours;
    findContours(canny,contours,RETR_EXTERNAL,CHAIN_APPROX_SIMPLE);
    // vector<vector<Point>> hull(contours.size());
    // vector<vector<Point>> poly(contours.size());
    vector<double> area(contours.size());
    vector<vector<Point>> final(contours.size());
    // int num=0;
    for(int i=0;i<contours.size();i++)
    {
    //     approxPolyDP(contours[i],poly[i],9,true);
    //     drawContours(polydp,poly,i,Scalar(255,255,255),1,LINE_AA,hierachy);
    //     convexHull(poly[i],hull[i]);
        area[i]=contourArea(contours[i],false);
        if(area[i]>0&&area[i]<2000)
        {
            drawContours(contours_,contours,i,Scalar(255,255,255),-1,LINE_AA);
            // drawContours(dst,hull,i,Scalar(255,0,0),1,LINE_AA,hierachy);
            // final[num++].data()=hull[i];
        }

    }
    // cout<<endl;
    // for(int i=0;i<final.size();i++)
    // {
    //     drawContours(dst,final,i,Scalar(255,0,0),1,LINE_AA,hierachy);
    // }

    //Mat dst=roadline(msg,src);
    if(a==0)
    {
        namedWindow("src",WINDOW_FREERATIO);
        namedWindow("gauss",WINDOW_FREERATIO);
        namedWindow("binary",WINDOW_FREERATIO);
        namedWindow("canny",WINDOW_FREERATIO);
        namedWindow("contours",WINDOW_FREERATIO);
        // namedWindow("polydp",WINDOW_FREERATIO);
        // namedWindow("dst",WINDOW_FREERATIO);
        a=1;
    }
    imshow("src",src);
    imshow("gauss",gauss);
    imshow("binary",binary);
    imshow("canny",canny);
    imshow("contours",contours_);
    // imshow("polydp",polydp);
    // imshow("dst",dst);
    waitKey(1);
}

int main(int argc, char **argv)  
{
  //Initiate ROS  
  init(argc, argv, "subscribe_and_publish");  

  //Create an object of class SubscribeAndPublish that will take care of everything  
  SubscribeAndPublish test;  
  //spin();
  MultiThreadedSpinner s(1);  //多线程
  spin(s); 

  return 0;  
} 

Mat polyfit(vector<Point>& in_point, int n , char x)
{
	int size = in_point.size();
	//所求未知数个数
	int x_num = n + 1;
	//构造矩阵U和Y
	Mat mat_u(size, x_num, CV_64F);
	Mat mat_y(size, 1, CV_64F);
 
	for (int i = 0; i < mat_u.rows; ++i)
		for (int j = 0; j < mat_u.cols; ++j)
		{
            if(x=='x')
			    mat_u.at<double>(i, j) = pow(in_point[i].x, j);
            else if(x=='y')
                mat_u.at<double>(i, j) = pow(in_point[i].y, j);
		}
 
	for (int i = 0; i < mat_y.rows; ++i)
	{
        if(x=='x')
		    mat_y.at<double>(i, 0) = in_point[i].y;
        else if(x=='y')
            mat_y.at<double>(i, 0) = in_point[i].x;
	}
 
	//矩阵运算，获得系数矩阵K
	Mat mat_k(x_num, 1, CV_64F);
	mat_k = (mat_u.t()*mat_u).inv()*mat_u.t()*mat_y;
	// cout << mat_k << endl;
	return mat_k;
}

Mat roadline(const ImageConstPtr & msg,Mat src)
{
    vector<Point> blue_point;
    vector<Point> red_point;

    if(roadblock.sign==1)
    {
        roadblock.red[roadblock.count.red].point=Point(msg->width,msg->height);
        roadblock.blue[roadblock.count.blue].point=Point(0,msg->height);
    }
    else
    {
        roadblock.red[roadblock.count.red].point=Point(0,msg->height);
        roadblock.blue[roadblock.count.blue].point=Point(msg->width,msg->height);
    }
    int i;
    for(i=0;i<roadblock.count.red+1;i++)
    {
        circle(src,roadblock.red[i].point,10,Scalar(255,0,0),CV_FILLED,CV_AA);
        // if(roadblock.red[i].point.x>msg->width/4&&roadblock.red[i].point.x<msg->width*3/4)
            red_point.push_back(roadblock.red[i].point);
    }
    for(i=0;i<roadblock.count.blue+1;i++)
    {
        circle(src,roadblock.blue[i].point,10,Scalar(0,0,255),CV_FILLED,CV_AA);
        // if(roadblock.blue[i].point.x>msg->width/4&&roadblock.blue[i].point.x<msg->width*3/4)
            blue_point.push_back(roadblock.blue[i].point);
    }
    int n=3;
    Mat mat_r = polyfit(red_point, n ,'y');
    Mat mat_b = polyfit(blue_point, n, 'y');
    for (int i =msg->height/3; i <msg->height; i++)
	{
		Point ipt;
		ipt.x = i;
		ipt.y = 0;
		for (int j = 0; j < n + 1; ++j)
		{
			ipt.y += mat_r.at<double>(j, 0)*pow(i,j);
		}
		circle(src, Point(ipt.y,ipt.x), 10, Scalar(0, 0, 255), CV_FILLED, CV_AA);
	}

    for (int i =msg->height/3; i <msg->height; i++)
	{
		Point ipt;
		ipt.x = i;
		ipt.y = 0;
		for (int j = 0; j < n + 1; ++j)
		{
			ipt.y += mat_b.at<double>(j, 0)*pow(i,j);
		}
		circle(src, Point(ipt.y,ipt.x), 10, Scalar(255, 0, 0), CV_FILLED, CV_AA);
	}
}




